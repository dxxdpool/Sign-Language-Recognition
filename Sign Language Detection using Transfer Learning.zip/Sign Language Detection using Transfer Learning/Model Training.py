import keras.models
import tensorflow as tf
from keras.src.applications.mobilenet_v2 import MobileNetV2
from keras.src.callbacks import ReduceLROnPlateau
from keras.src.optimizers import SGD
from keras.src.regularizers import regularizers
from tensorflow.keras import layers, models
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D, Dropout, BatchNormalization
from tensorflow.keras.models import Model
from tensorflow.keras.optimizers import Adam
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
sns.set()

classes = ['a', 'b', 'c', 'd', 'f', 'i', 's', 'u', 'v', 'w', 'y']

import numpy as np
from sklearn.metrics import classification_report, confusion_matrix

# Constants

image_size = (224, 224)  # Size of input images
batch_size = 10  # Batch size for training
epochs = 50  # Number of epochs

# Data preparation
train_data = tf.keras.preprocessing.image_dataset_from_directory(
    directory='ImageData/train',
    labels='inferred',
    label_mode='categorical',
    batch_size=batch_size,
    image_size=image_size,
    shuffle=True,
    seed=42,
)

# Number of classes in your dataset
num_classes = len(train_data.class_names)

test_data = tf.keras.preprocessing.image_dataset_from_directory(
    directory='ImageData/test',
    labels='inferred',
    label_mode='categorical',
    batch_size=batch_size,
    image_size=image_size,
    shuffle=False,
    seed=42
)

valid_data = tf.keras.preprocessing.image_dataset_from_directory(
    directory='ImageData/valid',
    labels='inferred',
    label_mode='categorical',
    batch_size=batch_size,
    image_size=image_size,
    shuffle=False,
    seed=42
)


def TrainModel(train_data):
    base_model = MobileNetV2(weights='imagenet', include_top=False, input_shape=image_size + (3,))
    for layer in base_model.layers:
        layer.trainable = False

    # Add global average pooling layer
    x = base_model.output
    x = GlobalAveragePooling2D()(x)

    x = Dropout(0.25)(x)
    x = Dense(512, activation='relu')(x)
    x = BatchNormalization()(x)

    # Add the final dense layer for classification
    x = Dense(len(train_data.class_names), activation='softmax')(x)

    # Create the final model
    model = Model(inputs=base_model.input, outputs=x)
    # reduce_lr = ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=5)

    model.compile(optimizer=SGD(learning_rate=0.001, momentum=0.9),
                  loss='categorical_crossentropy',
                  metrics=['accuracy'])

    H = model.fit(train_data, epochs=epochs, validation_data=valid_data)

    model.save('SignModel_MobileNetV2.keras')
    history_df = pd.DataFrame(H.history)

    # Save the DataFrame to an Excel file
    history_df.to_excel('training_history_MobileNetV2.xlsx', index=False)


def TestModel(test_data):
    model = keras.models.load_model('SignModel_MobileNetV2.keras')
    y_pred = np.argmax(model.predict(test_data), axis=-1)
    y_true = np.concatenate([y for x, y in test_data], axis=0)
    y_true = np.argmax(y_true, axis=1)

    # Generate classification report
    class_rep = classification_report(y_true, y_pred, output_dict=True, target_names=train_data.class_names)
    class_rep_df = pd.DataFrame(class_rep).transpose()
    class_rep_df.to_excel("classification_report.xlsx")

    conf_mat = confusion_matrix(y_true, y_pred)

    # Plot confusion matrix as heatmap
    plt.figure(figsize=(8, 6))
    sns.set(font_scale=1.2)  # Increase font size
    sns.heatmap(conf_mat, annot=True, fmt='d', cmap='Blues',
                xticklabels=classes, yticklabels=classes,
                cbar_kws={'label': 'Number of Samples'})  # Add color bar label
    plt.xlabel('Predicted labels', fontsize=14)  # Customize label font size
    plt.ylabel('True labels', fontsize=14)  # Customize label font size
    plt.title('Confusion Matrix', fontsize=16)  # Customize title font size
    plt.tight_layout()  # Adjust layout to prevent clipping of labels
    plt.show()

    history_df = pd.read_excel('training_history_MobileNetV2.xlsx')

    # Extract loss, validation loss, accuracy, and validation accuracy
    loss = history_df['loss']
    val_loss = history_df['val_loss']
    acc = history_df['accuracy']
    val_acc = history_df['val_accuracy']

    # Plot loss versus epochs
    epochs = range(1, len(loss) + 1)
    plt.figure(figsize=(10, 5))
    plt.plot(epochs, loss, label='Training Loss', color='red')
    plt.plot(epochs, val_loss, label='Validation Loss', color='blue')
    plt.title('Training and validation loss')
    plt.xlabel('Epochs')
    plt.ylabel('Loss')
    plt.legend()
    plt.show()

    # Plot accuracy versus epochs
    plt.figure(figsize=(10, 5))
    plt.plot(epochs, acc, label='Training Accuracy', color='orange')
    plt.plot(epochs, val_acc, label='Validation Accuracy', color='green')
    plt.title('Training and validation accuracy')
    plt.xlabel('Epochs')
    plt.ylabel('Accuracy')
    plt.legend()
    plt.show()

    print(class_rep)
    # print(model.summary())



# TrainModel(train_data)
TestModel(test_data)
